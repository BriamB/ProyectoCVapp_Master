from django.apps import AppConfig


class CarguecvConfig(AppConfig):
    name = 'carguecv'
